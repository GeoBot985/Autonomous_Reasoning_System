﻿def hello() -> str:
    return "hello, world"
