import time
import logging
import asyncio
from datetime import datetime
from Autonomous_Reasoning_System.control.dispatcher import Dispatcher
from Autonomous_Reasoning_System.control.router import Router
from Autonomous_Reasoning_System.cognition.intent_analyzer import IntentAnalyzer
from Autonomous_Reasoning_System.memory.memory_interface import MemoryInterface
from Autonomous_Reasoning_System.llm.reflection_interpreter import ReflectionInterpreter
from Autonomous_Reasoning_System.memory.confidence_manager import ConfidenceManager
from Autonomous_Reasoning_System.cognition.self_validator import SelfValidator
from Autonomous_Reasoning_System.cognition.learning_manager import LearningManager
from Autonomous_Reasoning_System.control.scheduler import start_heartbeat_with_plans
from Autonomous_Reasoning_System.planning.plan_builder import PlanBuilder
from Autonomous_Reasoning_System.planning.plan_executor import PlanExecutor
from Autonomous_Reasoning_System.control.attention_manager import attention
from Autonomous_Reasoning_System.tools.standard_tools import register_tools
from Autonomous_Reasoning_System.llm.context_adapter import ContextAdapter
from Autonomous_Reasoning_System.control.goal_manager import GoalManager
from Autonomous_Reasoning_System.tools.system_tools import get_current_time, get_current_location

# Dependencies for injection
from Autonomous_Reasoning_System.memory.storage import MemoryStorage
from Autonomous_Reasoning_System.memory.embeddings import EmbeddingModel
from Autonomous_Reasoning_System.memory.vector_store import DuckVSSVectorStore

logger = logging.getLogger(__name__)

class CoreLoop:
    def __init__(self, verbose: bool = False):
        # 1. Initialize Dispatcher first
        self.dispatcher = Dispatcher()
        self.verbose = verbose
        logger.setLevel(logging.DEBUG if verbose else logging.INFO)
        self._stream_subscribers: dict[str, set[asyncio.Queue]] = {}

        # 2. Initialize Core Services (Dependency Injection Root)
        self.embedder = EmbeddingModel()
        self.vector_store = DuckVSSVectorStore()
        self.memory_storage = MemoryStorage(embedding_model=self.embedder, vector_store=self.vector_store)

        # Initialize MemoryInterface with shared components to avoid split-brain
        self.memory = MemoryInterface(
            memory_storage=self.memory_storage,
            embedding_model=self.embedder,
            vector_store=self.vector_store
        )

        # 3. Initialize Components with injected dependencies
        self.plan_builder = PlanBuilder(
            memory_storage=self.memory_storage,
            embedding_model=self.embedder
        )
        self.context_adapter = ContextAdapter(memory_storage=self.memory_storage, embedding_model=self.embedder)

        self.reflector = ReflectionInterpreter(memory_storage=self.memory_storage, embedding_model=self.embedder)
        self.learner = LearningManager(memory_storage=self.memory_storage)
        self.confidence = ConfidenceManager(memory_storage=self.memory_storage)
        self.last_response = None

        # Tools that don't need memory injection or self-initiate harmlessly
        self.intent_analyzer = IntentAnalyzer()
        self.validator = SelfValidator()

        # 4. Initialize Control & Execution
        self.router = Router(dispatcher=self.dispatcher, memory_interface=self.memory)

        self.plan_executor = PlanExecutor(self.plan_builder, self.dispatcher, self.router)

        self.goal_manager = GoalManager(self.memory, self.plan_builder, self.dispatcher, self.router, plan_executor=self.plan_executor)

        # 3. Register Tools
        # We need to make sure 'memory' tool uses our instance, not a new one.
        components = {
            "intent_analyzer": self.intent_analyzer,
            "memory": self.memory,
            "reflector": self.reflector,
            "plan_builder": self.plan_builder,
            "context_adapter": self.context_adapter,
            "goal_manager": self.goal_manager
        }
        register_tools(self.dispatcher, components)

        # 5. Start Background Tasks
        start_heartbeat_with_plans(
            self.learner, self.confidence, self.plan_builder, interval_seconds=10, test_mode=True, plan_executor=self.plan_executor
        )
        self.running = False

        # Hydrate active plans
        self.plan_builder.load_active_plans()
        self.clear_stale_state()

    def run_once(self, text: str, plan_id: str | None = None):
        """
        Executes the Full Reasoning Loop:
        0. Check Goals
        1. Router (resolve pipeline)
        2. Plan Builder (create plan)
        3. Dispatcher (execute plan via PlanExecutor)
        4. Return Output
        5. Update Memory
        6. Reflection
        """
        logger.info(f"[CORE LOOP] Received input: {text}")
        start_time = time.time()

        # Add metrics
        from Autonomous_Reasoning_System.infrastructure.observability import Metrics
        Metrics().increment("core_loop_cycles")

        # --- Step 0: Check Goals (Periodic/Background) ---
        try:
            goal_status = self.goal_manager.check_goals()
            if goal_status and "No actions needed" not in goal_status:
                logger.debug(f"[GOALS] {goal_status}")
        except Exception as e:
            logger.error(f"[GOALS] Error checking goals: {e}")

        # --- Step 1: Use Router to determine pipeline ---
        route_decision = self.router.resolve(text)
        intent = route_decision["intent"]
        family = route_decision.get("family", "unknown")
        subtype = route_decision.get("subtype")
        pipeline = route_decision["pipeline"]
        entities = route_decision.get("entities", {})
        logger.debug(f"[ROUTER] Intent: {intent} (Family: {family}, Subtype: {subtype}) | Pipeline: {pipeline}")

        response_override = route_decision.get("response_override")

        # --- SHORT CIRCUIT: Birthday Handler ---
        if family == "personal_facts" and subtype == "birthday":
            logger.info("[SHORT CIRCUIT] Birthday detected. Engaging specialized handler.")

            # 1. Extract info (using entities from IntentAnalyzer)
            # Expect entities to contain name and date ideally, but we do best effort
            # If entities are missing, we might need to call extractor again or just rely on what we have
            # The IntentAnalyzer update should extract them.

            output_msg = "I've noted that birthday."

            # Store in KG
            # We need to identify subject and object (date)
            # Entities might look like {'subject': 'Nina', 'date': '11 January'} or similar
            # Or just generic keys. Let's assume intent analyzer does a decent job, or we use the raw text.

            # If intent analyzer didn't give structured entities, we can fallback to simple extraction or just storing the text as fact
            # But requirement says: "extract names + dates, store in KG"

            # Let's iterate entities to find potential name and date
            # If specific keys aren't guaranteed, we look at values.
            # This is a bit heuristic without a strict schema from IntentAnalyzer, but we updated it to try.

            stored_facts = []
            for key, value in entities.items():
                # Naive assumption: if it looks like a date, it's the object, else subject
                pass

            # For robustness, let's use the memory.remember with specific metadata
            # and also try to insert KG triple if we can parse it.
            # The prompt says "extract names + dates".
            # Let's assume the text itself is the fact if extraction is hard.

            # Actually, let's try to interpret the text if entities are sparse.
            # But since we must SHORT CIRCUIT, we do it here.

            # Store in Memory (Episodic)
            self.memory.remember(f"User told me: {text}", metadata={"type": "episodic", "intent": "birthday_fact"})

            # Store in KG (Fact)
            # We'll trust the IntentAnalyzer to have done some work, or we just store the raw fact as a 'note' that gets processed later?
            # No, requirement says "store in KG ... stop."
            # So we must try to insert a triple.

            # If we have entities, great.
            # Example: "Nina's birthday is 11 Jan" -> Entities: {"Nina": "Person", "11 Jan": "Date"}
            # We need "Nina has_birthday 11 Jan"

            # Let's blindly try to grab capitalized words as name if entity extraction failed?
            # No, let's rely on the text being stored as a "personal_fact" memory which the KGBuilder might pick up later asynchronously?
            # Requirement says "store in KG ... stop".
            # If we just store in memory, KGBuilder (if it runs on events) might do it.
            # But "stop. Do not pass through reflection...".

            # Let's explicitly add a memory that is highly likely to be picked up or insert triple directly if possible.
            # The MemoryInterface has insert_kg_triple.

            # We can try to use the text to extract triple using a quick regex or the entities.
            # If entities dict has keys, we use them.
            subject = None
            date_obj = None

            # Try to find subject and date from entities
            for k, v in entities.items():
                # Heuristics
                if any(x in k.lower() for x in ["date", "time", "day"]):
                    date_obj = v
                elif any(x in k.lower() for x in ["name", "person", "subject"]):
                    subject = v
                else:
                    # Fallback: assign to subject if missing, date if subject exists?
                    if not subject: subject = v
                    elif not date_obj: date_obj = v

            if subject and date_obj:
                 self.memory.insert_kg_triple(subject, "has_birthday", date_obj)
                 output_msg = f"I've saved {subject}'s birthday as {date_obj} in my permanent records."
            else:
                 # Fallback: Just store the text as a high-priority memory
                 self.memory.remember(text, metadata={"type": "personal_fact", "importance": 1.0})
                 output_msg = "I've saved that birthday date."

            logger.info(f"[SHORT CIRCUIT] Birthday handled: {output_msg}")

            # Return result immediately
            duration = time.time() - start_time
            result = {
                "summary": output_msg,
                "decision": route_decision,
                "plan_id": "birthday_shortcut",
                "duration": duration,
                "reflection": None
            }
            self._send_to_user(output_msg)
            return result
        # --- END SHORT CIRCUIT ---

        if response_override:
            final_output = response_override
            status = "complete"

            # Create a simple goal for logging purposes, but no plan execution
            goal = self.plan_builder.new_goal(text)
            plan = self.plan_builder.build_plan(goal, [text], plan_id=None)
            plan.id = f"fact_override_{plan.id}"
        else:
            # --- Step 2: Build a plan ---
            if intent == "plan" or intent == "complex_task" or family == "planning":
                goal, plan = self.plan_builder.new_goal_with_plan(text, plan_id=plan_id)
                logger.debug(f"[PLANNER] Created multi-step plan: {plan.id}")
                self._broadcast_thought(plan.id, f"Plan created with {len(plan.steps)} steps.")
            else:
                goal = self.plan_builder.new_goal(text)
                plan = self.plan_builder.build_plan(goal, [text], plan_id=plan_id)
                logger.debug(f"[PLANNER] Created single-step execution plan: {plan.id}")
                self._broadcast_thought(plan.id, "Single-step plan created.")

            # --- Step 3: Execute via Dispatcher ---
            execution_result = self.plan_executor.execute_plan(plan.id)

            final_output = ""
            status = execution_result.get("status")

            if status == "complete":
                summary = execution_result.get("summary", {})
                if len(plan.steps) > 0:
                    last_step = plan.steps[-1]
                    final_output = last_step.result or "Done."
                else:
                    final_output = "Plan completed with no steps."
            elif status == "suspended":
                 final_output = f"Plan suspended. {execution_result.get('message')}"
            else:
                final_output = f"Execution failed: {execution_result.get('errors')}"
                logger.warning(f"[EXEC] Failed: {final_output}")

        # --- Step 4: Return output ---
        logger.info(f"Tyrone response: {final_output}")

        # --- Step 5: Update Memory (Episodic + Semantic) ---
        interaction_summary = f"User: {text} | Intent: {intent} | Family: {family} | Result: {final_output}"
        self.memory.store(interaction_summary, memory_type="episodic", importance=0.5)
        logger.debug("[MEMORY] Interaction stored.")

        # --- Step 6: Store Reflection if enabled ---
        reflection_data = None

        # GUARDS:
        # 1. Never reflect if intent is memory_store
        # 2. Never reflect if intent is query and answer came from KG (we approximate this by checking if output starts with "Fact:")

        should_reflect = True
        if intent == "memory_store" or family == "memory_operations":
            should_reflect = False
            logger.debug("[REFLECTION] Skipped (memory_store intent).")

        # Check if answer came from KG (heuristic based on standard retrieval output or logic)
        # Since we don't easily know if it came from KG here without inspecting final_output structure deeply or passing flags,
        # we'll check if the output looks like a direct fact lookup result.
        if intent == "query" or family == "question_answering":
             if final_output.startswith("Fact:") or "Knowledge about" in final_output:
                 should_reflect = False
                 logger.debug("[REFLECTION] Skipped (KG answer detected).")

        if should_reflect and intent not in ["deterministic", "fact_stored"] and len(text) > 10:
            reflection_data = self.reflector.interpret(f"Reflect on this interaction: {interaction_summary}")
            if reflection_data:
                logger.debug(f"[REFLECTION] {reflection_data}")
                # Store reflection
                self.memory.store(str(reflection_data), memory_type="reflection", importance=0.3)
                # Reinforce confidence
                self.confidence.reinforce()

        # User corrections get stored explicitly
        lowered_text = text.lower()
        if any(term in lowered_text for term in ["no", "wrong", "actually", "not", "correction", "instead"]):
            if getattr(self, "last_response", None):
                self.memory.remember(
                    text=f"USER CONTRADICTED: {self.last_response}",
                    metadata={"type": "correction", "importance": 2.0}
                )

        duration = time.time() - start_time
        Metrics().record_time("core_loop_duration", duration)

        result = {
            "summary": final_output,
            "decision": route_decision,
            "plan_id": plan.id if plan else "override",
            "duration": duration,
            "reflection": reflection_data,
            # Legacy keys for tests
            "reflection_data": reflection_data
        }

        self._broadcast_thought(plan.id if plan else "override", f"Plan status: {status}. Output: {final_output}")
        self.last_response = final_output
        self._send_to_user(final_output)
        return result

    def initialize_context(self):
        """Initializes the context with system information (time, location)."""
        # Find Feet (Initialize Context)
        try:
            current_time = get_current_time()
            current_location = get_current_location()
            logger.info(f"[STARTUP] Feet found: {current_location} at {current_time}")
            self.context_adapter.set_startup_context({
                "Current Time": current_time,
                "Current Location": current_location
            })
        except Exception as e:
            logger.error(f"[STARTUP] Failed to find feet: {e}")

    def run_interactive(self):
        self.initialize_context()
        self.running = True
        logger.info("Tyrone Core Loop is running. Type 'exit' to stop.")

        while self.running:
            attention.set_silent(True)
            try:
                text = input("You: ").strip()
            finally:
                attention.set_silent(False)

            if not text:
                continue

            if text.lower() in {"exit", "quit"}:
                logger.info("Exiting core loop.")
                self.running = False
                break

            attention.acquire()
            try:
                self.run_once(text)
            except Exception as e:
                logger.error(f"Error in run_once: {e}", exc_info=True)
            finally:
                attention.release()

            logger.debug("---")

    # ------------------------------------------------------------------
    # API helpers for background execution and streaming
    # ------------------------------------------------------------------
    def clear_stale_state(self):
        """Remove stale/unfinished goals from prior sessions to start clean."""
        try:
            with self.memory_storage._write_lock:
                self.memory_storage.con.execute(
                    "DELETE FROM goals WHERE status NOT IN ('completed', 'failed')"
                )
            logger.info("Cleared stale plans from previous sessions.")
        except Exception as e:
            logger.error(f"Failed to clear stale plans: {e}")

    def _send_to_user(self, message: str):
        """Send user-facing messages while filtering internal progress spam."""
        if not message:
            return

        spam_markers = [
            "Plan update",
            "step",
            "Current step: None",
            "Reminder: Continue plan",
            "Last action result",
            "0/1 steps complete",
            "%. Current step:",
        ]
        if any(marker in message for marker in spam_markers):
            logger.debug(f"[INTERNAL] {message}")
            return

        # IMPORTANT: DO NOT print() in the Gradio environment.
        # Logging is safe; stdout is not.
        logger.info(f"Tyrone> {message}")

        # Broadcast to any stream queues if present
        for queues in self._stream_subscribers.values():
            for q in queues:
                try:
                    q.put_nowait(message)
                except Exception:
                    continue



    def run_background(self, goal: str, plan_id: str):
        """Run a goal asynchronously for API calls."""
        asyncio.get_event_loop().create_task(self._run_goal_async(goal, plan_id))

    async def _run_goal_async(self, goal: str, plan_id: str):
        result = await asyncio.to_thread(self.run_once, goal, plan_id)
        self._broadcast_thought(plan_id, f"Completed plan {plan_id}")
        # Signal end
        self._broadcast_thought(plan_id, None)
        return result

    def get_plan_status(self, plan_id: str):
        """Return plan progress summary if available."""
        summary = self.plan_builder.get_plan_summary(plan_id)
        if summary and "error" not in summary:
            return summary
        return None

    def subscribe_stream(self, plan_id: str, queue: asyncio.Queue):
        self._stream_subscribers.setdefault(plan_id, set()).add(queue)

    def unsubscribe_stream(self, plan_id: str):
        if plan_id in self._stream_subscribers:
            for q in list(self._stream_subscribers[plan_id]):
                try:
                    q.put_nowait(None)
                except Exception:
                    pass
            del self._stream_subscribers[plan_id]

    def _broadcast_thought(self, plan_id: str | None, thought: str | None):
        """Push messages to SSE subscribers."""
        if not plan_id or plan_id not in self._stream_subscribers:
            return
        # Filter spammy internal chatter
        if thought:
            spam_markers = [
                "Plan update",
                "step",
                "Current step: None",
                "Reminder: Continue plan",
                "Last action result",
                "0/1 steps complete",
                "%. Current step:",
            ]
            if any(marker in thought for marker in spam_markers):
                logger.debug(f"[INTERNAL] {thought}")
                return
        for q in list(self._stream_subscribers.get(plan_id, [])):
            try:
                q.put_nowait(thought)
            except Exception:
                continue


if __name__ == "__main__":
    tyrone = CoreLoop()
    tyrone.run_interactive()
