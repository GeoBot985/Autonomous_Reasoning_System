import re
import datetime
import time
import logging
from typing import List
from .memory import MemorySystem

logger = logging.getLogger("ARS_Retrieval")

class RetrievalSystem:
    def __init__(self, memory_system: MemorySystem):
        self.memory = memory_system
        
        # EXPANDED STOPWORDS (Crucial for filtering "tell me about")
        self.stop_words = {
            "the", "is", "at", "which", "on", "a", "an", "and", "or", "but", 
            "if", "then", "else", "when", "where", "who", "what", "how", 
            "do", "does", "did", "can", "could", "should", "would", "to", "from",
            "of", "in", "for", "with", "about", "as", "by", "hey", "hi", "hello",
            "tyrone", "please", "thanks", "thank", "is", "are", "was", "were",
            "very", "really", "so", "much", "too", "quite", "just",
            "good", "great", "perfect", "nice", "cool", "ok", "okay", "awesome",
            "yes", "no", "sure", "right", "correct", "done", "fine",
            "stuff", "thing", "things", "something", "anything",
            # NEW ADDITIONS:
            "tell", "me", "you", "your", "my", "mine", "us", "we", "know", "find"
        }
        
        self.generic_terms = {
            "birthday", "born", "date", "time", "schedule", "plan", "detail", 
            "info", "information", "remember", "remind", "note"
        }

    def get_context_string(self, query: str, include_history: List[str] = None) -> str:
        print(f"[Retrieval] 🟢 Building context for: '{query}'")
        start_t = time.time()
        
        context_lines = ["### SYSTEM CONTEXT ###"]
        context_lines.append(f"Current Time: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        context_lines.append("Location: Cape Town, Western Cape, South Africa") 

        keywords = self._extract_keywords_fast(query)
        print(f"[Retrieval]    🔑 Keywords: {keywords}")
        
        if not keywords:
            print(f"[Retrieval]    🚀 Trivial query — skipping heavy search")
            return "\n".join(context_lines)
        
        facts = self._retrieve_deterministic(keywords)
        print(f"[Retrieval]    📂 Facts found: {len(facts)}")
        
        limit = 1 if facts else 3
        print(f"[Retrieval]    🧠 Requesting vectors...")
        vec_start = time.time()
        vectors = self.memory.search_similar(query, limit=limit, threshold=0.35)
        print(f"[Retrieval]    ✅ Vectors: {len(vectors)} ({time.time() - vec_start:.2f}s)")

        if facts or vectors:
            context_lines.append("\n### RELEVANT MEMORY (FACTS) ###")
            seen_hashes = set()
            chars_added = 0
            MAX_CHARS = 2000 

            if facts:
                for f in facts:
                    clean_f = f.replace('\n', ' ')
                    h = hash(clean_f)
                    if h not in seen_hashes and chars_added < MAX_CHARS:
                        context_lines.append(f"- [FACT] {clean_f}")
                        seen_hashes.add(h)
                        chars_added += len(clean_f)
            
            if vectors:
                for v in vectors:
                    text = v['text']
                    clean_v = text.replace('\n', ' ')
                    h = hash(clean_v)
                    if h not in seen_hashes and chars_added < MAX_CHARS:
                        context_lines.append(f"- [MEMORY] {clean_v}")
                        seen_hashes.add(h)
                        chars_added += len(clean_v)
        else:
            context_lines.append("\n(No specific relevant memories found)")

        if include_history:
            context_lines.append("\n### RECENT CONVERSATION ###")
            context_lines.extend(include_history[-5:]) 

        print(f"[Retrieval] 🏁 Context built ({time.time() - start_t:.2f}s)")
        return "\n".join(context_lines)

    def _retrieve_deterministic(self, keywords: List[str]) -> List[str]:
        results = []
        strong_keywords = [k for k in keywords if k[0].isupper() and k.lower() not in self.generic_terms]
        
        if strong_keywords:
            search_terms = strong_keywords
            print(f"[Retrieval]    🎯 Strategy: Specific Entities Only {search_terms}")
        else:
            search_terms = keywords
            print(f"[Retrieval]    🔍 Strategy: Broad Search {search_terms}")

        for kw in search_terms:
            triples = self.memory.get_triples(kw)
            results.extend(triples[:3])

            text_matches = self.memory.search_exact(kw, limit=3)
            for tm in text_matches:
                results.append(tm['text'])

        return results

    def _extract_keywords_fast(self, text: str) -> List[str]:
        # 1. Strip possessives
        text = re.sub(r"'s\b", "", text, flags=re.IGNORECASE)
        
        # 2. Clean text BUT KEEP DOTS AND HYPHENS (Fix for kalahari.net)
        # We allow alphanumeric, spaces, dots, and hyphens
        clean_text = re.sub(r'[^\w\s\.\-]', '', text)
        
        tokens = clean_text.split()
        keywords = []
        
        for t in tokens:
            # Strip trailing dots (e.g. "sentence end.")
            t = t.strip('.')
            
            if not t: continue
            
            # 3. Filter
            if (t[0].isupper() or len(t) > 2) and t.lower() not in self.stop_words:
                keywords.append(t)
                
        return list(set(keywords))